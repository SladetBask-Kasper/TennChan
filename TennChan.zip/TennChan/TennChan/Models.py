from django.db import models
#from django import forms

class Picture(models.Model):
	img = models.ImageField(upload_to='images/%Y/%m/%d', blank=True)

	def __str__(self):
		return self.title
