class CookieHandler:
	