#from django.http import HttpResponse, HttpResponseRedirect
#from django.template import Context, loader
from .header import *

# Create your views here.
def index(request):
	#return HttpResponse(DEFAULT)
	bcount = 0
	boards = ""
	#for i in s.get("SELECT subboard FROM posts GROUP BY subboard;"):
	for i in s.get("SELECT board_name, pinned_post FROM tennchan.board_list ORDER BY id;"):
		bcount += 1
		boards += f"<a href='/subboards/{i[0]}/'>Sub board number {bcount} - /{i[0]}/</a><br>"
		boards += f"<a href='/subboards/{i[0]}/' class='post_desc wrap'>{i[1]}</a><br><br><hr><br>\n"

	return render(request, "index.html", context={
		"boards": boards,
	})

def showPost(request, question_id):

	comments = ""
	content = ""
	title = ""
	subboard = ""
	for i in s.get(f"SELECT nick, comment_content, imgPath, posterId from comments WHERE post_id = {question_id};"):
		comment_content = ""
		inGreenText = False
		commentList = i[1].replace("\n", " !n ")
		for char in commentList.split():
			if char == "&gt;":
				inGreenText = True
				comment_content += "<p style='color:green'>"
			elif char.lower() == "!n":
				inGreenText = False
				comment_content += "</p>\n"
				continue
			comment_content += str(char) + " "

		nickname = f"<a href=\"/reply/{question_id}/{ i[3] }\" class=\"nickname tooltip\" id=\"{ i[3] }\"><span class='tooltiptext'>{i[3]}</span>{i[0]}</a>"
		args = ""
		endArgs = ""
		if not i[2] == "None":
			comments += '<a href="' + i[2] + '" target="_blank"><img src="' + i[2] + '" class="commentPic" alt="PICTURE NOT FOUND" width="128" height="128"></a>\n'
			#args += "<div style='float:right;'>"
			#endArgs += "</div>"
			endArgs += "<br>"*6
		comments += f"{nickname} : {args}{comment_content.strip()}{endArgs}<br><hr><br>"

	# I actually don't remeber why this is in a for loop, i think it will return a tuple array so it should be 
	# the first and only set of tuples it loops.
	for i in s.get(f"SELECT nick, title, content, date, subboard, imgPath, posterId FROM posts WHERE id = {question_id};"):
		date = ""
		for word in i[3].split("-"):
			if len(str(word)) < 2:
				date += "0"
			date += word + "-"


		title += f"{i[1]} (posted by <a href='/reply/{question_id}/{i[6]}' class='op tooltip'><span class='tooltiptext'>{i[6]}</span>{i[0]}</a> {date[:-1]})"
		if not i[5] == "None":
			content += '<a href="' + i[5] + '" target="_blank"><img src="' + i[5] + '" class="commentPic" alt="PICTURE NOT FOUND" width="256" height="256"></a>\n'
		content += str(i[2])
		subboard = i[4]

	return render(request, "post.html", context={
		"post_title": title,
		"post_content": content.replace("!n", "<br>"),
		"post_comments": comments.replace("!n", "<br>"),
		"board": subboard,
		"postId": question_id
	})

@check_recaptcha
def post(request): 
	ip = request.META["REMOTE_ADDR"]

	req = getReq(request.get_full_path().replace("/post/", ""))
	postBoard = ""
	try:
		postBoard = str(req[0])
	except:
		#return err(request, "Invalid URL.")
		req = ""
	if len(postBoard) < 1:
		postBoard = "e"

	#cookie_name='8a^&KaZT453Aj1' # old cookie
	cookie_name='zk9^mA48YUG55J'
	userID = Security.getId(request)
	if request.session.get(cookie_name, "None") == "None":
		key = str(Security.get_random_key(64))
		request.session[cookie_name] = key
		CookieHandler.makeCookie(cookie_name+":"+key, userID)
		#CookieHandler.makeCookie(cookie_name, userID)
	else:
		print(request.session.get(cookie_name, "None"))


	if request.method == "POST":
		form = InputForm(request.POST, request.FILES)
		if form.is_valid():

			#if not request.recaptcha_is_valid:
			#	return err(request, "Invalid reCaptcha")
			
			cookie_value = request.session.get(cookie_name, "None")
			expected_values = CookieHandler.getCookieById(userID)
			if cookie_value == "None":
				return err(request, "It seems you have not loaded the site correctly or have cookies disabled.")
			correctCookie = False
			for i in expected_values:
				if not cookie_name+":"+cookie_value == i[0]:
					continue
				else:
					CookieHandler.deleteCookie(cookie_value)
					request.session[cookie_name] = "None"
					correctCookie = True
					break
			if not correctCookie:
				print(cookie_name+":"+cookie_value, "\t",expected_values)
				return err(request, "Invalid session. Please try again by going to home page.")

			nickname = ban(form.cleaned_data['nickname'])
			subboard = ban(str(form.cleaned_data['subboard']).lower().replace("/", ""))
			if len(subboard) < 1:
				return err(request, "Invalid subboard.")
			if s.isEmpty(f"SELECT board_name FROM board_list WHERE board_name = '{subboard}';"):
				return err(request, f"Unknown board /{subboard}/")
			postBoard = subboard
			title = ban(form.cleaned_data['title'])
			content = ban(form.cleaned_data['content'])
			imgName = "None"
			try:
				newpic = Picture(img=request.FILES['img'])
				newpic.save()
				imgName = newpic.img.url
			except KeyError:
				imgName = "None"

			if ((len(content) >= 1024 and len(content) < 1) or 
				(len(title) >= 45 and len(title) < 1) or 
				(len(nickname) < 1 and len(nickname) >= 45) or 
				(not len(subboard) == 1)):
				return err(request, "Invalid length on post content or/and title")

			date = getDate()
			sqlcmd = f"INSERT INTO `tennchan`.`posts` (`subboard`, `nick`, `title`, `content`, `date`, `imgPath`, `posterId`) VALUES ('{subboard}', '{nickname}', '{title}', '{content}', '{date}', '{imgName}', '{userID}');"
			lastId = s.post(sqlcmd)
			
		else: return err(request, "Invalid request")
		return HttpResponseRedirect(f'/subboards/{postBoard}/')
	form = InputForm()
	form.fields['nickname'].initial = "Anon"
	form.fields['subboard'].initial = postBoard
	context ={} 
	context['form']= form
	context['board']= postBoard
	context['SITE_KEY'] = Captcha.SITE_KEY
	return render(request, "newpost.html", context) 

@check_recaptcha
def comment(request): 

	req = request.get_full_path().replace("/comment/", "")
	if len(req) >= 3:
		if req[:3] == "?q=":
			req = req[3:]
		else:
			req = ""
	else:
		req = ""
	postId = -1
	if len(req) >= 1 and isInt(req):
		postId = int(req)

	cookie_name='92@voSu5vpcRDm'
	userID = Security.getId(request)
	if request.session.get(cookie_name, "None") == "None":
		key = str(Security.get_random_key(64))
		request.session[cookie_name] = key
		CookieHandler.makeCookie(cookie_name+":"+key, userID)
	else:
		print(request.session.get(cookie_name, "None"))

	if request.method == "POST":
		form = CommentForm(request.POST, request.FILES)
		if form.is_valid():

			#if not request.recaptcha_is_valid:
			#	return err(request, "Invalid reCaptcha")

			cookie_value = cookie_name+":"+request.session.get(cookie_name, "None")
			expected_values = CookieHandler.getCookieById(userID)
			if cookie_value == cookie_name+":None":
				return err(request, "It seems you have not loaded the site correctly or have cookies disabled.")
			correctCookie = False
			for i in expected_values:
				if not cookie_value == i[0]:
					continue
				else:
					CookieHandler.deleteCookie(cookie_value)
					request.session[cookie_name] = "None"
					correctCookie = True
					break
			if not correctCookie:
				print(cookie_value,expected_values)
				return err(request, "Invalid session. Please try again by going to home page.")

			nickname = ban(form.cleaned_data['nickname'].replace("*", "").replace(":", ""))
			content = ban(form.cleaned_data['content'])

			containsImg = True
			imgName = "None"
			try:
				newpic = Picture(img=request.FILES['img'])
				newpic.save()
				imgName = newpic.img.url
			except KeyError:
				containsImg = False

			postId = form.cleaned_data['postId']
			if postId < 1:
				print(postId)
				return err(request, "Bad post id. Please stop sucking.")
			if s.isEmpty(f"SELECT id FROM tennchan.posts WHERE id = {postId};"):
				return err(request, "The post you tried to comment on seems to have been deleted.")

			if ((len(content) >= 256 and len(content) < 1) or
				(len(nickname) < 1 and len(nickname) >= 45)):
				return err(request, "Invalid length on post content or/and title")
			userID = Security.getId(request)
			date = getDate()
			lastId = s.post(f"INSERT INTO `tennchan`.`comments` (`nick`, `comment_content`, `time`, `post_id`, `imgPath`, `posterId`) VALUES ('{nickname}', '{content}', '{date}', '{postId}', '{imgName}', '{userID}');")
		else: return err(request, "Invalid request")
		return HttpResponseRedirect(f'/{postId}/')
	#return HttpResponseRedirect('/')

	form = CommentForm()
	form.fields['nickname'].initial = "Anon"
	form.fields['postId'].initial = postId
	context ={} 
	context['form']= form
	context['SITE_KEY'] = Captcha.SITE_KEY
	return render(request, "comment.html", context) 

def subboard(request, board):
	board = ban(board.lower().replace("/", ""))
	if s.isEmpty(f"SELECT board_name FROM board_list WHERE board_name ='{board}';"):
		return err(request, f"Unknown board /{board}/")

	post_titles = ""
	pin = s.get(f"SELECT pinned_post FROM tennchan.board_list WHERE board_name = '{board}';")[0]
	post_titles += f"<a href='/pin/{board}/' class='post'><nickname>Pinned Post*</nickname>: Welcome to /{board}/</a><br>\n"
	post_titles += f"<a href='/pin/{board}/' class='post_desc wrap'>{pin[0]}</a><br><hr><br>\n"
	for item in s.get(
		f"SELECT id, nick, title, SUBSTRING(content, 1, 128) FROM posts WHERE subboard = '{board}' ORDER BY id DESC;"):
		post_titles += f"<a href='/{item[0]}/' class='post'><nickname>{item[1]}</nickname>: {item[2]}</a><br>\n"
		post_titles += f"<a href='/{item[0]}/' class='post_desc wrap'>{item[3]}</a><br><hr><br>\n"

	return render(request, "default.html", context={
		f"board_name": board,
		"posts": post_titles
		})
def pin(request, board):
	board = ban(board.lower().replace("/", ""))
	content = ""
	rules = ""

	data = s.get(f"SELECT pinned_post, rules FROM tennchan.board_list WHERE board_name = '{board}';")[0]
	content = data[0]
	rules = data[1].replace("!n", "<br>")

	return render(request, "pin.html", context={
		"post_content": content,
		"post_rules": rules,
		"board": board
	})

def reply(request, postId, posterId):
	form = CommentForm()
	form.fields['nickname'].initial = "Anon"
	form.fields['postId'].initial = postId
	form.fields['content'].initial = f"To !{posterId}!:"
	context ={} 
	context['form']= form
	context['SITE_KEY'] = Captcha.SITE_KEY
	return render(request, "comment.html", context) 