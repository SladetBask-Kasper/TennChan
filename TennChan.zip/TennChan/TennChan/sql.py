import mysql.connector
from .headers.log import *

# Time staps:
# https://ilmanzo.github.io/programming/2016/05/05/automatic-expiring-of-mysql-rows

class MySQL:
	###
	### Example s = sql.MySQL("localhost", "root", "qwe123!!", "tennchan")
	###
	def __init__(self, ip, uname, passwd, db):
		self.ip=str(ip)
		self.uname=str(uname)
		self.passwd=str(passwd)
		self.database=str(db)
		self.connect()

		msg = important("Scanning for invalid cookies")

		available = self.get("SELECT cookie_uid FROM cookie_cache;")
		valid = []
		for item in self.get("SELECT public_id FROM security_id;"):
			valid.append(item[0])

		for i in available:
			item = i[0]
			if item in valid:
				print("valid:", item)
			else:
				print("invalid:", item, "(DELETED)")
				self.post(f"DELETE FROM cookie_cache WHERE cookie_uid = '{item}';")
		del msg
		#exit()
		#self.mycursor = self.mydb.cursor()
		self.reconnect()
	def connect(self):
		self.mydb = mysql.connector.connect(
		  host=self.ip,
		  user=self.uname,
		  password=self.passwd,
		  database=self.database
		)
	def disconnect(self):
		self.mydb.close()
	def reconnect(self):
		self.disconnect()
		self.connect()
	def post(self, cmd):

		mycursor = self.mydb.cursor()
		lastId = None
		
		"""mycursor.execute(str(cmd))
		self.mydb.commit()
		lastId = mycursor.lastrowid"""
		try:
			mycursor.execute(str(cmd))
			self.mydb.commit()
			lastId = mycursor.lastrowid
		except KeyboardInterrupt:
			print("ERROR POSTING SQL")
		#return (mycursor, lastId)
		return lastId
	def get(self, cmd):
		mycursor = self.mydb.cursor()
		mycursor.execute(str(cmd))
		return mycursor.fetchall()
	def getTable(self,table, items = "*"): return get(f"SELECT {items} FROM {table}")
	def isEmpty(self, cmd):
		if len(self.get(cmd)) <= 0:
			return True
		return False